<template>
  <div id="app">
    <router-view />
  </div>
</template>


<style>
@import url("./util/style.css");
* {
  margin: 0;
  padding: 0;
}
body {
  background: #eeebff;
}
</style>
