Page({
  data: {
    navActive: 0,
    prom: {
      txt: '',
      yzm: ''
    },
    num: 0,
    openid: ''
  },
  // 验证码切换
  qiehuan() {
    var ind = Math.floor(Math.random() * (1000000 - 1)) + 1;
    this.setData({
      num: ind
    })
  },
  yzminp(v) {
    this.setData({
      'prom.yzm': v.detail.value
    })
  },
  saveTxt() {
    if (this.data.prom.txt == '') {
      tt.showToast({
        title: '反馈内容不能为空',
        icon: 'fail'
      });
      return
    } else if (this.data.prom.yzm == '') {
      tt.showToast({
        title: '验证码不能为空',
        icon: 'fail'
      });
      return
    }
    tt.request({
      url: 'https://tgadmin.clvtmcn.cn/api/message/messageAdd',
      method: 'POST',
      data: {
        message: this.data.prom.txt,
        code: this.data.prom.yzm,
        num: this.data.num
      },
      success: (res) => {
        console.log(res.data, "结果")
        if (res.data.code == 1) {
          tt.showToast({
            title: '提交成功',
          });
          this.setData({
            'prom.txt': '',
            'prom.yzm': ''
          })
        } else {
          tt.showToast({
            title: res.data.msg,
            icon: 'fail'
          });
          this.setData({
            'prom.yzm': ''
          })
        }
      }
    });
  },
  onTextInput(v) {
    this.setData({
      'prom.txt': v.detail.value
    })
  },
  navAct(v) {
    this.setData({
      navActive: v.currentTarget.dataset.index
    })
  },
  onLoad: function (options) {
    this.setData({
      userinfo: tt.getStorageSync('userInfo'),
      openid: options.openid
    })
    var ind = Math.floor(Math.random() * (1000000 - 1)) + 1;
    this.setData({
      num: ind
    })
  },
  onShow() {
    this.setData({
      navActive: 0
    })
  },
  onShareAppMessage(option) {
    // option.from === 'button'
    return {
      title: "资讯百宝箱",
      desc: "资讯百宝箱，延伸你的视野！",
      path: `/pages/index/index?from=sharebuttonabc&otherkey=othervalue&id=资讯百宝箱&openid=${this.data.openid}`,
      // imageUrl: '',
      templateId: '4csdk0ph0k62j48etv',
      success() {
        console.log('转发发布器已调起，并不意味着用户转发成功，微头条不提供这个时机的回调');
      },
      fail() {
        console.log('转发发布器调起失败');
      }
    }
  }
})