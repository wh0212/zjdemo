App({
  globalData: {
    userInfo: null
  },
  onLaunch: function () { }
})